#!/bin/bash

output_file_cased=ChatGPT4.cased.raw.norm
output_file_uncased=ChatGPT4.uncased.raw.norm

for file in $(ls -1v ./*.chatgpt4.postproc); do
    echo "Processing $file"
    cat $file >> $output_file_cased
done

tr '[:upper:]' '[:lower:]' < $output_file_cased > $output_file_uncased