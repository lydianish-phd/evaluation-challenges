Im ready, im ready!
Im hella excited!
Might be picking up a new sponsor!
Will be posting more here once I get...comfortable again.
(Self love is impt!)
I’m on and off though, and have quite a bit of messages to go through ~ will get to them when I can :3
In the meantime, happy new year!!
ps: I don’t have a SC & don’t take any $$$, I just like to.. show off, y’know closet slut things :) lol
Ttyl y’all
He said "shhh just kis me you fool".
I still love him and I cried so much on valentine's weekend (dont judge lmao) , but I said "No. You're f***ed up now.
Whats going on?"
He never replied to me afterwards, and this interaction took about 10 minutes through text.
Today he says "good lord wtf happened.
I gotta garden
ttyl".
He read my reply which said "I'm so worried about you!
Why would you take that?
Where did you find it and why would you take it?
Eat and stay hydrated".
I just don't know anymore.
I suspected it, but I want him to be upfront about it with me.
I love him and he will always be my first and I'll always talk to him and care for him, but I don't want to be held in limbo.
I'm trying to move on and this is now in my head.
I know when ever I say ttyl or gn or whatever I wanna add an ily. Just casually. To see what happens.
I know that every time I get a text from them I get super excited.
I know when I am having a bad day just thinking of them makes me feel so much better.
Just knowing I can go home and text them brightens my mood ten fold.
I know sometimes I day dream about just holding them and being near them.
But what I don’t know is what this means.
I’ve known them nearly four months now.
That’s not long.
Makes me feel like this is an infatuation that will pass.
Tbh I kinda hope it is bc I don’t think it’s mutual.
But oof is it hitting me hard.
Is it merely infatuation?
Their explanation is that they’re a bad texter, or busy, but honestly so am I(will takes days or a week to respond) but I don’t leave people on read or open messages I know I can’t respond to atm.
It really isn’t that hard to send a quick ttyl either tbh.
Finally they seem to want to engage w/ me and basically tell me they’re going to an event and they’d hope to see me there, which they reaffirm the next day and then day of.
I go to event, they never show.
At this point I’m too stressed from a lot of other shit I got going on and it’s not like we’re really talking so I just block them.
Idk, I need to change my mindset or this and that for my benefit and survival,
I'm still "Ocean Serene" but maybe I'm .. idk that's a tough thing to say, I never thought that my gf was just a random,
I love her to death, she is my boo and will always be it.
Just like I said allot of things, I'm gonna agree that if I change the world changes,
the advice you get, it's allways iffy,
I want to speak for everyone but at the same time I can only speak for myself,
also I went to get some rum and coke,
I got coke and a few other people seen it so they bought some coke.. erm, I hope my friends are ok (that's all you weirdos I'm talking about)
random story I know,
tbh I'm not ok, but I'm surviving like usual,
actually I'm all just a bit Right and fine.
Ttyl
[bro] Across the country?
She acts like 500 miles is a long way.
[me] lol, its 8 hrs to [redacted]. 7 to [redacted].
not a big deal
[bro] I suppose when you don’t maintain your vehicles an hour drive could be detrimental.
[me] lol
[me] i spose [redacted] or [redacted]'s wife ratted me out.
maybe i should block them too
[bro] Sorry for her awkward messages.
I was in the middle of a drunk nap when she pulled up to my house and I told her you jumped ship.
Told her not to try to contact you and we can see how well that went.
[me] shiiiiiiiiit. betrayal
[bro] I’m sure she’s contacting you for her own self gratification.
I was in a toxic rs for 4 months.
During our dating period and a month or so into our rs we were great.
One day both of us were jealous of each other for no reason.
Im going to admit that sometimes when i feel jealous i just want her to reassure me like how i reassure her that its all good but she will only reassure me once and then said bye or ttyl.
Most of the time in an argument its always my fault,
she wont admit to anything or say sorry.
I will always be the one to give in so that the fight wont continue anymore
And I said "But yeah yeah you right."
And he said "Ye well I gtg. Im doing something" and I was gonna type aight ttyl but I realized we ain’t at that level anymore.
I didn’t like that.
The vibe was going good.
I didn’t have a bad vibe. When the convo started.
But once he said he’s doing something my heart dropped.
Like what was he doing?
He’s never done this before.
This was such a different person.
I hate it.
What can I do?
All these attempts I made were basically shut down.
I like him but I’m not trying to flirt or do anything!
I know he doenst like me like that.
We talked about it.
Right now I’m just chatting with him.
But he doesn’t seem like he...wants to do that.
If he doenst want to talk to me he can just fucking tell me.
Idk what else to put Besides that i hate the current circumstance of life i live in
im gonna give a little insight tomorrow
Ok i lied
i have to reveal my age tomorrow because if i dont Itll mess up the story
Um Idk what to type so ill type a worry i have
Umm i dont think ill get the tapegun intime
Ok bye ttyl everyone
she said something like "but i want to make sure that we go as a friend?" thing and i was like "okay, i know" and sometimes she talks about her relationship and she said "ofc i like my long time bf"
yea, whatever right haha
