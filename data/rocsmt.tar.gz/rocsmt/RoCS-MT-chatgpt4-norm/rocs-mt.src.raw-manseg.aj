Back to the topic.
Honestly the king and queen of this game is lancelot and his beloved fanny.
Yoo know, to keep it safe from me in little car where I can go anywhere.
And then Mom-O desidez to go to gym to do kwik workout, whatever dat iz.
She sez to me, "Yoo leave steak alone, doggo. Yoo be gud gurl!"
She tied plastik bag reel tite around steak.
Hahahaha!
Then she goes into gym and when she comez bak many furevers later, GUESS WHAT??
Hahahaha!
She open tiny car and look at me and look at steak bag....and she say, "GUD GURL!!!
Yoo leeve steak alone!"
And dat is da storee of me bein' gud gurl.
Mom-O sez she shud have brought steak into gym and left on bench next to her wiff her sweatshirt.
Sez she dum not to think of dat.
Mebbe Mom-O will git smart in a few furevers.
My bed smells like disease
i shud probz wash it
Pls send me some tips n stuff on what to teach him.
Currently hes doing pretty good, though the only thing he buys is shotguns because thats the only gun he gets kills from.
I alrdy taught him the basics like planting the spike and things like that.
Btw this is coming from an iron 3 player (hardstuck, friends say i shud be silver and some even say plat cuz i carried a gold player)
Uk how some MFS exist?
Literally get close to u ,then all of a sudden u have problems and even tho u apologize again and again and again no it's never enuf for them .
I was in a gmeet but i told them if be back in 10 .
I forgot my ph so i went to get it and guess what them spkin abt u and backstabbing u.
U srsly don't know what to do and whom to trust anymore.
maybe i am overthinking but I'd rather die alone than live between these kinda PPL.
maybe i should just ignore them?
Or shud i give them another chance?
Or maybe i am just wierd lol
l have developed feels for my best friend.
now the question is shud l tell her how l feel about her??
will this affect our relationship tht we have.
how will she take??
ive been waiting for two years now. savings from thEn and i barely made 200usd till now.
im still styding and gaming is my dream.. and these prices are giving me depression and hopelessness fom life.....,,tBh...
what shud i get?
a monitor or a gpu... ?
some of u are so lucky to get a gpu for free in here.. lol..
Aita , me (31f) asked my kids dad (43m)to help me finish off stripping wallpaper in kids room so I can finish decorating it.
I recently had surgery and am not ment to lift too much or stretch but felt OK n thought I could do it alone .
I can't,
I hurt my incisions so asked him to help do the top of walls were I can't reach .
He said yes n today came to do it ,
after a bit said he was done and leaving,
I gave him £20 n said how greatful I am for the help .
Checked room once he left ...
both kids beds full of torn off we wallpaper , draws cracked where he stood on ,
iv still 2 walls left unfinished and have spent last 45 min picking up wallpaper from everything.
His kids sleep on these beds ,
aita if I confront him about the mess or shud I let it go n not bother asking in future
my boyfriend gets impatient easily and gets annoyed when i ask dumb questions (example, i didnt know how to fill my tire and he got annoyed after he explained it once and then said "why is it hard….. just fill it"
so i tried to do it but i failed.
later he was like "babe… it took you an hour to fill your tire?"
then when i do it myself and dont ask him he goes "why dont you ask me, i can teach you/help you" but i refrain from asking becuz he gets frustrated
The last couple calls had arguments as he got mad cuz I beat his ass in video games (even tho gaming is his only hobby) and I’ve left wondering if our relationship is worth the trouble.
I’ve talked abt him to lots of my irl friends and they all ask why I continue to be his friend and I can never confidently answer why.
But he’s depressed and lonely and wants my attention as I’m one of the only ppl who actively tries to interact w him online.
yeah Ik shoes don't match.
they match the graffiti tho !
I'm trying alot of different styles so lmk what I shud change
hat: sicko by Ian conner
shoes: Nike
everything else is thrifted
ok so i swallowed a small piece of box(?) tape as i was trying to bite it off w my teeth n then i feel it in my ear😭 not ear but tht hole in my throat tht leads to the ear its jus stuck there omg😭😭😭
what shud i do lol
She had me live with a woman once named Chi who said similar stuff , and … it’s just dude wt… heck it’s weird ,
so maybe it’s BOTH sort of a paradox (life is) but I just wanna know Hinestly did anyone else feel it ?
I want a logical explanation Plz , n if one don’t exist well I mean cuz loooong before … I was "of age" so to speak … for lack of more efficient words that would be appropriate cuz I don’t drink but I’ve … hmm I’m an adult let’s put it like that
there’s other stjfff out there but Long before thag me and myFamily saw a UFO
even mg step dad said he couldn’t think of what else it could’ve been and me and my friends saw this white hooded thing in a park about 10 feet tall n like … it doesn’t really scare me cuz I think it’s the way life is
things change
they don’t always have to make sense , and others say that 2.
Here is an example of two paragraphs written in the alternate spelling system and then in regular spelling:
>Dh North Wind and dh Snn wr dispyuuting wic wzz dh strawngr, wen a travllr keim llawng rapd in a wourm klok.
Dhei ggriid dhat dh wnn hu frst skksiided in meiking dh travllr teik hiz klok awf shud bi knsidrrd strawngr dhn dh ddhr.
Dhen dh North Wind blu az haard az hi kud, btt dh mor hi blu dh mor klosli did dh travllr fold hiz klok rraund him; and at last dh North Wind geiv pp dh ttempt.
Dhen dh Snn shaind aut wourmli, and imiidiietli dh travllr tuk awf hiz klok.
And so dh North Wind wzz oblaijd tu knnfes dhat dh Snn wz dh strawngr v dh tu.
>Dhat kwik beizh fawks jmmpd in dh er ovr iich thin dawg nndr a kaam awtmm muun.
Luk aut, Y shaut, for hi's foild yu yet ggen, crieiting keiaws.
hu wud win,
plz give detailed explanation
Ares (Greek mythology) vs. Mars (Roman mythology) vs. Svetovid (Slavic mythology) vs. Odin (Norse mythology) vs. The Big Bang (Atheistic mythology)
i much redy.
i veri gud.
eye wud liek 2 aply 4 vilage idot
Shud I get horizon zero dawn or elex cause they are the same price right now so wot shud I buy
just looking for reason.
Btw I like open world alot and shooters eg. Skyrim, Battlefield, COD, Ark Survival Evolved.
So any idea s on wot I shud be
btw I wud prefer them rlly quick.
Thanx in advance.
Thanx four de suggstions guise,
we r going to tRy 2 gt the Ak 477 cuz some1 sAid it wud halp, butt wheRe dO we fnd it?!
Plz halp wiff it
we can'T do it alone c:
I reside in Hyderabad,India, currently pursuing my bachelors in computer science .
I am a candian citizen but,for enrollment it is required to appear for the IELTS exam .
Now,the doubt that has arose is...wud my admission be considered international or domestic?..
