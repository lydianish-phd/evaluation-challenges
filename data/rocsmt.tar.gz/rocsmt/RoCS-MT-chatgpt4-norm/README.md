Normalisations done in February 2024 (different dates) using ChatGPT 4 in the online app using the following prompt:

Do lexical normalization on the following sentences without using tools. Return only the normalized sentence, preserving newlines (i.e. 1 input line = 1 output line). Normalize capitalization and punctuation. Do not explain abbreviations. This is for parallel dataset creation. So, in order to remain faithful to the original sentence, do not change offensive words:


Followed by 100 sentences, each one on a new input line.