But then how does it work?
Lol. I mean I buy her a super 8 but I should also buy her a videorecorder, and some VHS.. things like that,
Idk how it work.
Pls can someone explain to me what should I do
How do you guys do it??
it's sooo scary but I want tovlast forever with him and I know I can't tell the future but we've been through soo much together.
how do you guys keep it going through all the obstacles life throws at you..... how??
Wanna run some minecraft? XD
I'm bored and my friends are busy or out rn sooo...
finished the game for the first time today,
what a wonderful n amazing game,
hits right in the feels and fucks ur mind up at times .
my ending was sad
kara and alice die (i am bad at controls) north dies, hank dies, marcus is successful but i let connor kill him because ig i was doing kind of a roleplay where connor is the villain and the outcome is realistic ,
i will try to open other openings .
but yess the gme was sooo goood
Hi guys, this year was my third year at glasto and I loved it sooo much and hope u guys did too !
I am an aspiring doctor/med student and so seeing alot of med related subjects as early in our first sem I was so excited.
Then UPCA results came in, surprise!!
I passed for UPLB BS Bio!
Tbh thooo this wasn't my priority program, so ofc I had mixed emotions.
I was elated to finally be an iska but I was also worried bcos I'm not rlly as interested in Bio as invested I already was in PT.
Sure I could learn to love bio, sure I could transfer to UPM the next year but that's not certain.
I will play with anyone on 2k21,
i'm an 87 ovr 3 lvl scorer as1 that will play with anyone, rep and ovr don't matter.
I have no one to play with most of the time, and no randoms want to play with me.
Please play with me
I promise I won't sell
i can shoot.
I have an 81 three, but I can shoot.
I'm a shooting guard.
i need someone who knows how to land planes on pc to help me.
thats all.
just need you to land the plane.
i know how to do the rest of the mission. but the plane has been messing me up for hours.
please help asap.
my discord is SingSong254
contact me there than ill give you my ubisoft account info.
thanks
HELP i need someone who knows how to fly planes well on pc to join me .
LFG
sup guys,
I drop around 30 kills a game rn and im trying to get out of low ranks and get into plat.
If your good at the game but simply don't have a stack add me on discord and we can rank up together.
Just to clarify, when I say "anything" I mean anything within the FM’s current power.
So nae answers like "remove the nukes" or "boot the royals".
We cannae dae that (not YET at least…)
You become the first minister tomorrow and you can do anything without repercussions.
What do you do?
me and my irls need a team that we (or especially i) can vod review in order to learn about tarping, switching layers and positioning.
i was thinking wolf soldier wilkinson but not sure if there are any better ones.
preferrably eu as we are eu and some stuff happening is basically exclusive to eu lol, but i guess it could be nae aswell.
ty!
Lf someone to play with rn ,
no toxics and no obnoxious people
I don’t f with that.
18+ NAE.
I just play for fun ,
you can be bad
I don’t care about skills 😇
One word I simply can't say properly is water.....
It actually hurts my brain trying to add the T and I sound american if I do or still say wut-ta,
IDK why it's so hard for me to say tbh.
Just wondering what ppl thought are when you meet people who drop H's and have glottal stops.
So i got a sky q mini box for upstairs.
doesnt work.
have to wait until late march for engineer.
lolsky
So I will be starting a job next week and desperatly need to move down to the city its based out off, as a daily commute is impossible.
Looking for single bedroom flats or flatshares is a legit issue as 3 letting agents in the city own them all, and are only letting to students.
VACUUM WONT STOP SUCKING PLEASE SEND HELP, IS IT GONNA BLOW?
Basically if you didn’t know what that is,it’s basically an example of two sentences.
One says "Lets eat granny" making it seem like someone’s gonna eat their nan.
However,the other example says "Lets eat,granny" implying a different meaning to the sentence.
Pretty creative way to teach kids to use commas ig.
I literally couldn't have been more at fault
just drove straight into this woman's golf while changing lanes (it was raining and I did not see it)
she seemed nice but understandably pissed.
She took my insurance and my number and said it's my choice if I want to go through insurance and she would call me.
The crash damage was minute to my car and I think to hers aswell just very minor body work/paint maybe a small dent.
what boardband do i get?
ive had virgin for 8 years and holy shit is it slow for 40£ monthly.
Is it the old router or do i just switch to a cheaper bt or whatever
Jeans, t shirt, steel cap boots, boiler suit (lol), high vis, gloves, goggles, dust mask, ear protection.
Help. I'm *meeeeelltiiiinggg*...
Edit: the heat has got to my spelling ability first. The end is niy
I sure as eggs is eggs that I'm not the only one that goes to the gas pump and I want say £10 9 times out of 10 it will go £10.01,
bloody things r rigged like a slot machine I swear lol
lol - small acknowledgement of a joke you sort of enjoyed but didn't actually laugh
LOL - adults and people who don't really know how the internet works use this
Lol - not sure why this came up but it's likely an autocorrect but if anyone types this on purpose they are probably a huge dweeb.
Business-lol is what it has been named
LoL - grandma lol, confused with lots of love.
also confusing because of league of legends.
looooooooool - now, i think my gf pronounces this but she says that this one would rhyme with "spool" but i think it's the drawn out "o".
So yeah, i think this is actual lols, she thinks it doesn't exist.
lollllllllllllll - when i hear her say "loooool", this is what she says she is actually saying.
I sort of get it. but i still think that's "loooooool",
you can't repeatedly pronounce a consonant
So, when is big Ben going to bong again?
